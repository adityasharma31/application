﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CustomerApp.Entity;

namespace CustomerApp.Exception
{
    public class CustomerException:ApplicationException 
        // User defined exception class is inherited.
    {
        // User defined Excpetion constructor.
        public CustomerException(string exceptionMessage):base(exceptionMessage)
        {
            // "exceptionmessage" is the message that will be displayed to the user. 
        }
    }
}
