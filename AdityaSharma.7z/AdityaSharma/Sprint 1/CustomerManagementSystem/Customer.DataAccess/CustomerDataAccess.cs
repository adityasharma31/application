﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Customer.Entity;
using Customer.Exception;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;


namespace Customer.DataAccess
{
    public class CustomerDataAccess
    {
        List<CustomerEntity> customers = new List<CustomerEntity>();
        int position = 0;
        public bool AddCustomer(CustomerEntity customer)
        {
            bool isAdded = false;
            try
            {
                customers[position] = customer;
                position++;
                isAdded = true;
                string path = @"C:\Users\ASHAR398\Desktop\serial\sample4.txt";
                Stream stream = File.Open(path, FileMode.OpenOrCreate, FileAccess.ReadWrite);
                BinaryFormatter binaryFormat = new BinaryFormatter();
                binaryFormat.Serialize(stream, customers);
                stream.Close();
                Console.WriteLine("serialized");
            }
            catch (CustomerException customerException)
            {
                Console.WriteLine(customerException.Message);
            }
            catch (System.Exception exception)
            {
                Console.WriteLine(exception.Message);
            }
            return isAdded;
        }

     
        
    }
}
