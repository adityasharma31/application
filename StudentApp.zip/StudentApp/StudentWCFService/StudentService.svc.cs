﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace StudentWCFService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class Service1 : IStudentService
    {
        SqlConnection con = new SqlConnection(@"Data Source=NDAMSSQL\SQLILEARN;Database=Training_23Jan20_Pune;uid=sqluser;pwd=sqluser");
        SqlCommand cmd = null;
        SqlDataReader dr = null;
        public int AddStudent(Student stud)
        {
            int recordsAffected = 0;

            try
            {
                cmd = new SqlCommand("INSERT INTO Student_Master (Stud_Code, Stud_Name, Dept_Code, Stud_Dob, Address) VALUES (@scode, @sname, @dcode, @dob, @address)", con);
                cmd.Parameters.AddWithValue("@scode", stud.StudCode);
                cmd.Parameters.AddWithValue("@sname", stud.StudName);
                cmd.Parameters.AddWithValue("@dcode", stud.DeptCode);
                cmd.Parameters.AddWithValue("@dob", stud.StudDob);
                cmd.Parameters.AddWithValue("@address", stud.Address);

                con.Open();
                recordsAffected = cmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }

            return recordsAffected;
        }

        public int DeleteStudent(int id)
        {
            int recordsAffected = 0;

            try
            {
                cmd = new SqlCommand("DELETE FROM Student_Master WHERE Stud_Code = @scode", con);
                cmd.Parameters.AddWithValue("@scode", id);

                con.Open();
                recordsAffected = cmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }

            return recordsAffected;
        }

        public List<Student> DisplayStudents()
        {
            List<Student> studList = new List<Student>();

            try
            {
                cmd = new SqlCommand("SELECT * FROM Student_Master", con);
                con.Open();
                dr = cmd.ExecuteReader();
                if(dr.HasRows)
                {
                    while (dr.Read())
                    {
                        Student stud = new Student();
                        stud.StudCode = Convert.ToInt32(dr["Stud_Code"]);
                        stud.StudName = dr["Stud_Name"].ToString();
                        stud.DeptCode = Convert.ToInt32(dr["Dept_Code"]);
                        stud.StudDob = Convert.ToDateTime(dr["Stud_Dob"]);
                        stud.Address = dr["Address"].ToString();
                        studList.Add(stud);
                    }
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }

            return studList;
        }

        public string GetData(int value)
        {
            return string.Format("You entered: {0}", value);
        }

        public CompositeType GetDataUsingDataContract(CompositeType composite)
        {
            if (composite == null)
            {
                throw new ArgumentNullException("composite");
            }
            if (composite.BoolValue)
            {
                composite.StringValue += "Suffix";
            }
            return composite;
        }

        public Student SearchStudent(int id)
        {
            Student stud = null;

            try
            {
                cmd = new SqlCommand("SELECT * FROM Student_Master WHERE Stud_Code = @scode", con);
                cmd.Parameters.AddWithValue("@scode", id);

                con.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        stud = new Student();
                        stud.StudCode = Convert.ToInt32(dr["Stud_Code"]);
                        stud.StudName = dr["Stud_Name"].ToString();
                        stud.DeptCode = Convert.ToInt32(dr["Dept_Code"]);
                        stud.StudDob = Convert.ToDateTime(dr["Stud_Dob"]);
                        stud.Address = dr["Address"].ToString();
                    }
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }

            return stud;
        }

        public int UpdateStudent(Student stud)
        {
            int recordsAffected = 0;

            try
            {
                cmd = new SqlCommand("UPDATE Student_Master (Stud_Name = @sname, Dept_Code = @dname, Stud_Dob = @dob, Address = @address) WHERE Stud_Code = @scode", con);
                cmd.Parameters.AddWithValue("@sname", stud.StudName);
                cmd.Parameters.AddWithValue("@dcode", stud.DeptCode);
                cmd.Parameters.AddWithValue("@dob", stud.StudDob);
                cmd.Parameters.AddWithValue("@address", stud.Address);
                cmd.Parameters.AddWithValue("@scode", stud.StudCode);

                con.Open();
                recordsAffected = cmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }

            return recordsAffected;
        }
    }
}
