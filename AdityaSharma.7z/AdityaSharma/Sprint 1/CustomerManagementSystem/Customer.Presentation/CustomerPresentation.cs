﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Customer.Exception;
using Customer.Entity;
using Customer.BusinessLogic;

namespace Customer.Presentation
{
    class CustomerPresentation
    {
        static void Main(string[] args)
        {
            CustomerBusinessLogic businessLogic = new CustomerBusinessLogic();
            int choice;
            try
            {
                while (true)
                {
                    Console.WriteLine("Customer Operations");
                    Console.WriteLine("1. Add");
                    Console.WriteLine("2. Display");
                    Console.WriteLine("3. Exit");
                    Console.WriteLine("Enter your choice");
                    choice = Convert.ToInt32(Console.ReadLine());

                    switch (choice)
                    {

                        case 1:
                            if (businessLogic.CheckCustomerAndAdd(ReadContact()))
                            {
                                Console.WriteLine("Contact info Added successfully");
                            }
                            else
                            {
                                Console.WriteLine("Error adding contact info!");

                            }
                            break;

                        case 2:
                            //int size = businessLogic.GetAllcontacts().Length;
                            //CustomerEntity[] customers = new CustomerEntity[size];
                            //customers = businessLogic.GetAllcustomers();
                            //foreach (CustomerEntity customer in customers)
                            //{
                            //    Console.WriteLine($" {customer.CustomerId} {customer.CustomerName} {customer.CustomerCity} {customer.CustomerAge} {customer.CustomerPhone} {customer.CustomerPincode}");

                            //}

                            break;
                        case 3:
                            Environment.Exit(0);
                            break;
                        default:
                            Console.WriteLine("Invalid choice!");
                            break;
                    }

                }
            }
            catch (CustomerException customerException)
            {
                Console.WriteLine(customerException.Message);
            }
            catch (System.Exception exception)
            {
                Console.WriteLine(exception.Message);
            }
            Console.ReadKey();

        }
        public static CustomerEntity ReadContact()
        {
            CustomerEntity customer = new CustomerEntity();
            try
            {

                Console.WriteLine("Enter the id");
                customer.CustomerId = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the name");
                customer.CustomerName = Console.ReadLine();
                Console.WriteLine("Enter the City");
                customer.CustomerCity = Console.ReadLine();
                Console.WriteLine("Enter the Age");
                customer.CustomerAge = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the Phone No");
                customer.CustomerPhone = Convert.ToInt64(Console.ReadLine());
                Console.WriteLine("Enter the Pincode");
                customer.CustomerPincode = Convert.ToInt64(Console.ReadLine());
            }
            catch (CustomerException customerException)
            {
                Console.WriteLine(customerException.Message);
            }
            catch (System.Exception exception)
            {
                Console.WriteLine(exception.Message);
            }
            return customer;
        }
    }
    
}
