﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace StudentWebApp
{
    public partial class SearchStudent : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        ServiceReference1.StudentServiceClient service = new ServiceReference1.StudentServiceClient();

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(txtStudCode.Text);
                ServiceReference1.Student stud = service.SearchStudent(id);
                if (stud != null)
                {
                    txtStudName.Text = stud.StudName;
                    txtDeptCode.Text = stud.DeptCode.ToString();
                    txtDob.Text = stud.StudDob.ToString();
                    txtAddress.Text = stud.Address;
                    btnUpdate.Enabled = true;
                    btnDelete.Enabled = true;
                }
                else
                {
                    Response.Write("<script type='text/JavaScript'>alert('Student Info not found');</script>");
                    btnUpdate.Enabled = false;
                    btnDelete.Enabled = false;
                }
            }
            catch (SystemException ex)
            {
                Response.Write("<script type='text/JavaScript'>alert('" + ex.Message + "');</script>");
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {

        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {

        }
    }
}