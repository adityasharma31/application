﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CustomerApp.Entity;
using CustomerApp.Exception;
using CustomerApp.DataAccess;
using System.Text.RegularExpressions;

namespace CustomerApp.BusinessLogic
{
    public class CustomerLogics
    {
        CustomerDataAccess dataAccess = new CustomerDataAccess();
        // This will provide the addition checker functionality.

        Regex regexForID = new Regex("^[0-9]{6}$");
        Regex regexForName = new Regex("^[A-Za-z]*$");
        // This checks the name with just one string like "Bill".

        Regex regexForName2 = new Regex("^[A-Za-z]+ [A-Za-z]+$");
        // This checks the name with two strings like "Mike Tyson".

        Regex regexForName3 = new Regex("^[A-Za-z]+ [A-Za-z]+ [A-Za-z]+$");
        // This checks the name with three strings like "Shruti Tanwar Patro".

        Regex regerForCity = new Regex("^[a-zA-Z]*$");
        // This takes the city with one string like "Maharashtra".

        Regex regexForCity2 = new Regex("^[A-Za-z]+ [A-Za-z]+$");
        // This takes the city with two strings like "New Delhi".

        Regex regexForPhoneNumber = new Regex(@"^[2-9]\d{2}\d{3}\d{4}$");
        Regex regexForPincode = new Regex("^[0-9]{6}$");
        public bool CheckingCustomerInfo(CustomerEntity customer)
        // Information validation function.
        {
            bool itsCorrectInput = false;
            try
            {
                if (dataAccess.UniqueId(customer.CustomerID).Equals(true))
                {
                    throw new System.InvalidOperationException("ID cannot be same, enter another ID");
                }
                else
                    itsCorrectInput = true;
                if (regexForID.IsMatch(Convert.ToString(customer.CustomerID)))
                    // Customer ID validation.
                    itsCorrectInput = true;
                else
                    return false;
                if (regexForName.IsMatch(customer.CustomerName) || regexForName2.IsMatch(customer.CustomerName) || regexForName3.IsMatch(customer.CustomerName))
                    itsCorrectInput = true;
                else
                    return false;
                if (regerForCity.IsMatch(customer.CustomerCity) || regexForCity2.IsMatch(customer.CustomerCity))
                    itsCorrectInput = true;
                else
                    return false;
                if (Convert.ToInt64(customer.CustomerAge) > 18 && Convert.ToInt64(customer.CustomerAge) < 58)
                    itsCorrectInput = true;
                else
                    return false;
                if (regexForPhoneNumber.IsMatch(Convert.ToString(customer.CustomerPhoneNumber)))
                    itsCorrectInput = true;
                else
                    return false;
                if (regexForPincode.IsMatch(Convert.ToString(customer.CustomerPincode)))
                    itsCorrectInput = true;
                else
                    return false;
            }
            catch (CustomerException exceptionMessage)
            {
                Console.WriteLine(exceptionMessage.Message);
            }
            catch (System.Exception generalException)
            // Catching the general exceptions.
            {
                Console.WriteLine(generalException.Message);
            }
            return itsCorrectInput;
        }
        public bool CheckCustomerAndAdd(CustomerEntity customer)
        // Calls the validate method and adds into the List
        {
            bool isCheckedForAdd = false;
            try
            {
                if (CheckingCustomerInfo(customer))
                    isCheckedForAdd = dataAccess.AddCustomer(customer);
                else
                    isCheckedForAdd = false;
            }
            catch (CustomerException exceptionMessage)
            {
                Console.WriteLine(exceptionMessage.Message);
            }
            catch (System.Exception generalException)
            // Catching the general exceptions.
            {
                Console.WriteLine(generalException.Message);
            }
            return isCheckedForAdd;
        }
        public List<CustomerEntity> DisplayOfLogics()
        {
            return dataAccess.DisplayOfDataAccess();
        }
    }
}
