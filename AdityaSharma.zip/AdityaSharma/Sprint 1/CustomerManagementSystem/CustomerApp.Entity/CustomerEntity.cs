﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerApp.Entity
{
    [Serializable]
    public class CustomerEntity 
        // This class has all the namse of the varibles.
    {
        public double CustomerID { get; set; } 
        // Customer ID that the user makes on his own just like a username.
        public string CustomerName { get; set; }
        // Name of the customer.
        public string CustomerCity { get; set; }
        // The city in which the customer lives.
        public string CustomerAge { get; set; }
        // Age of the customer.
        public double CustomerPhoneNumber { get; set; }
        // Phone number of the customer.
        public double CustomerPincode { get; set; }
        // Pincode of the area in which the customer lives.
    }
}
