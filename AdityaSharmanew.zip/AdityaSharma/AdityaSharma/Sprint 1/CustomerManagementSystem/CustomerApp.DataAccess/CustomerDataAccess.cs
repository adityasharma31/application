﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CustomerApp.Entity;
using CustomerApp.Exception;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace CustomerApp.DataAccess
{
    public class CustomerDataAccess
    // This is the basic data access layer.
    {
        public static string path = @"C:\Users\Aspire 5\source\repos\AdityaSharma\AdityaSharma\Sprint 1\CustomerManagementSystem\ListValues.txt";

        public static List<CustomerEntity> customerEntities = new List<CustomerEntity>();

        public bool AddCustomer(CustomerEntity customer)
        {
            bool isAdditionDone = false;
            //customerEntities = DisplayOfDataAccess();
            customerEntities.Add(customer);
            BinaryFormatter formatter = new BinaryFormatter();
            Stream stream = File.Open(path, FileMode.Open, FileAccess.Write);
            formatter.Serialize(stream, customerEntities);
            stream.Close();
            isAdditionDone = true;
            return isAdditionDone;
        }
        public List<CustomerEntity> DisplayOfDataAccess()
        {
            BinaryFormatter formatter = new BinaryFormatter();
            Stream stream = File.Open(path, FileMode.Open, FileAccess.Read);
            List<CustomerEntity> entityList = (List<CustomerEntity>)formatter.Deserialize(stream);
            stream.Close();
            return entityList;
        }
      

    }
}

