﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DBFirst_PMS
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        ProductContext context = new ProductContext();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnAddProduct_Click(object sender, RoutedEventArgs e)
        {
            string Name=txtProductName.Text;
            float Price = float.Parse(txtPrice.Text);
            int Quantity = int.Parse(txtQuantity.Text);

            products_46023367 product = new products_46023367()
            {
                ProductNAme = Name,
                Price = Price,
                Quantity = Quantity
            };
            context.products_46023367.Add(product);
            context.SaveChanges();
            MessageBox.Show("Product Added Successfully");
            LoadGrid();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LoadGrid();
        }
        private void LoadGrid()
        {
            dgProducts.DataContext = context.products_46023367.ToList();
        }

        private void btnSearchProduct_Click(object sender, RoutedEventArgs e)
        {
            int ProductId = int.Parse(txtProductId.Text);
            products_46023367 searchProduct = context.products_46023367.ToList().Find(product=>product.ProductId==ProductId);
            
            if(searchProduct!=null)
            {
                MessageBox.Show("Product Found");
                txtProductName.Text = searchProduct.ProductNAme;
                txtPrice.Text = searchProduct.Price.ToString();
                txtQuantity.Text = searchProduct.Quantity.ToString();
            }
            else
            {
                MessageBox.Show("Product Not Found");
            }
        }

        private void btnUpdateProduct_Click(object sender, RoutedEventArgs e)
        {
            int ProductId = int.Parse(txtProductId.Text);
            products_46023367 searchProduct = context.products_46023367.ToList().Find(product => product.ProductId == ProductId);

            string Name = txtProductName.Text;
            float Price = float.Parse(txtPrice.Text);
            int Quantity = int.Parse(txtQuantity.Text);

            searchProduct.ProductNAme = Name;
            searchProduct.Price = Price;
            searchProduct.Quantity = Quantity;

            context.SaveChanges();
            MessageBox.Show("Product Details Updated Succesfully");
            LoadGrid();
        }

        private void btnDeleteProduct_Click(object sender, RoutedEventArgs e)
        {
            int ProductId = int.Parse(txtProductId.Text);
            products_46023367 searchProduct = context.products_46023367.ToList().Find(product => product.ProductId == ProductId);
            context.products_46023367.Remove(searchProduct);
            context.SaveChanges();
            MessageBox.Show("Product Deleted Successfully");
            LoadGrid();
        }

        private void btnFilterProduct_Click(object sender, RoutedEventArgs e)
        {
            List<products_46023367> products = context.products_46023367.ToList().FindAll(product => product.Price > 50);
            dgProducts.DataContext = products;
        }

        private void btnFilterByName_Click(object sender, RoutedEventArgs e)
        {
            string productName = txtProductName.Text;
            List<products_46023367> products = context.products_46023367.ToList().Where(product => product.ProductNAme.Contains(productName)).ToList();
            dgProducts.DataContext = products;
        }

        private void btnDisplayProductName_Click(object sender, RoutedEventArgs e)
        {
            string productName = txtProductName.Text;
            List<products_46023367> products = context.products_46023367.ToList().Where(product => product.ProductNAme.Contains(productName)).ToList();
            dgProducts.DataContext = products.GroupBy(name => name.ProductNAme);
        }
    }
}
