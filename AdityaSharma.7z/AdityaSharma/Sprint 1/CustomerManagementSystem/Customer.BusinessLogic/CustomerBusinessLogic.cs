﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Customer.Entity;
using Customer.Exception;
using Customer.DataAccess;
using System.Text.RegularExpressions;


namespace Customer.BusinessLogic
{
    public class CustomerBusinessLogic
    {
        CustomerDataAccess dataAccess = new CustomerDataAccess();
        Regex regressionId = new Regex("[0 - 9]{4}");
        Regex regressionName = new Regex("[a-zA-Z]");
        Regex regressionCity = new Regex("[a-zA-Z]");
        Regex regressionAge = new Regex("[0-9]{2}");
        Regex regressionPhone = new Regex("[0-9]{10}");
        Regex regressionPincode = new Regex("[0-9]{6}");
        public bool CheckCustomerInfo(CustomerEntity customer)
        {
            bool isCorrect = false;
            try
            {
                if (regressionId.IsMatch(Convert.ToString(customer.CustomerId)))
                {
                    isCorrect = true;
                }
                if (regressionName.IsMatch(customer.CustomerName))
                {
                    isCorrect = true;
                }
                if (regressionCity.IsMatch(customer.CustomerCity))
                {
                    isCorrect = true;
                }
                if (regressionAge.IsMatch(Convert.ToString(customer.CustomerAge)))
                {
                    isCorrect = true;
                }
                if (regressionPhone.IsMatch(Convert.ToString(customer.CustomerPhone)))
                {
                    isCorrect = true;
                }
                if (regressionPincode.IsMatch(Convert.ToString(customer.CustomerPincode)))
                {
                    isCorrect = true;
                }
            }
            catch (CustomerException customerException)
            {
                Console.WriteLine(customerException.Message);
            }
            catch (System.Exception exception)
            {
                Console.WriteLine(exception.Message);
            }
            return isCorrect;
        }

        public bool CheckCustomerAndAdd(CustomerEntity customer)
        {
            bool isCheckedAdded = true;
            try
            {
                if (CheckCustomerInfo(customer))
                {
                    dataAccess.AddCustomer(customer);
                }
                else
                {
                    isCheckedAdded = false;
                }
            }
            catch (CustomerException customerException)
            {
                Console.WriteLine(customerException.Message);
            }
            catch (System.Exception exception)
            {
                Console.WriteLine(exception.Message);
            }
            return isCheckedAdded;
        }
        //public CustomerEntity[] GetAllcustomers()
        //{

        //    CustomerEntity[] customers = null;
        //    try
        //    {
        //        int size = dataAccess.Serialize().Length;
        //        customers = new CustomerEntity[size];
        //        customers = dataAccess.ContactList();
        //    }
        //    catch (CustomerException customerException)
        //    {
        //        Console.WriteLine(customerException.Message);
        //    }
        //    catch (System.Exception exception)
        //    {
        //        Console.WriteLine(exception.Message);
        //    }
        //    return customers;
        //}
    }
}
