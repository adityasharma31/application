﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CustomerApp.Entity;
using CustomerApp.Exception;
using CustomerApp.BusinessLogic;
using static System.Console;

namespace CustomerApp.Presentation
{
    class CustomerPresentation
    {
        static void Main(string[] args)
        {
            CustomerPresentation customerPresentation = new CustomerPresentation();
            CustomerLogics customerLogics = new CustomerLogics();
            // This will provide all the logics functionality.

            int choiceFromMainMenu;
            try
            {
                while(true)
                {
                    WriteLine("----------------------------------------------------");
                    WriteLine("\tCUSTOMER MANAGEMENT SYSTEM");
                    WriteLine("----------------------------------------------------");
                    WriteLine();
                    WriteLine("1. Create new users");
                    WriteLine("2. Display all the users");
                    WriteLine("3. Delete a user");
                    WriteLine("4. Exit");
                    choiceFromMainMenu = Convert.ToInt32(ReadLine());
                    // Taking the value of choice from the user.

                    switch(choiceFromMainMenu)
                    {
                        case 1:
                            int choiceOfUsers;
                            WriteLine("Enter the number of users you want to add");
                            choiceOfUsers = Convert.ToInt32(ReadLine());
                            

                            for(int counter = 0;counter<choiceOfUsers;counter++)
                            {
                                if (customerLogics.CheckCustomerAndAdd(Create()))
                                {
                                    WriteLine("Contact info Added successfully");
                                }
                                else
                                {
                                    WriteLine("Error adding contact info!");
                                }
                            }
                            break;
                        case 2:
                            List<CustomerEntity> customers= customerLogics.DisplayOfLogics();
                            if (customers.Count > 0)
                            {
                                Console.WriteLine("-------------------------------------------------------------------------------------------------------");
                                Console.WriteLine("CustomerID | CustomerName | CustomerCity | CustomerAge | CustomerPhoneNo | CustomerPincode");
                                Console.WriteLine("-------------------------------------------------------------------------------------------------------");
                              foreach (var item in customers)
                              {   
                                Console.WriteLine($"{item.CustomerID}\t   |\t{item.CustomerName} \t|\t{item.CustomerCity} \t|\t{item.CustomerAge}\t|   {item.CustomerPhoneNumber}   |\t{item.CustomerPincode}");
                                Console.WriteLine();
                              }
                            }
                            else
                                WriteLine("Error caused while de-serialization");
                            break;
                        case 3:
                            break;
                        case 4:
                            Environment.Exit(0);
                            break;
                    }
                }
            }
            catch (CustomerException exceptionMessage)
            {
                WriteLine(exceptionMessage.Message);
            }
            catch (System.Exception generalException)
            // Catching the general exceptions.
            {
                WriteLine(generalException.Message);
            }
        }
 
        public static CustomerEntity Create()
        {
            CustomerEntity customer = new CustomerEntity();
            try
            {
                WriteLine("Enter the ID that you want : ");
                customer.CustomerID = Convert.ToDouble(ReadLine());
                WriteLine("Enter your name please : ");
                customer.CustomerName = ReadLine();
                WriteLine("Enter the city you live in");
                customer.CustomerCity = ReadLine();
                WriteLine("Enter your Age please : ");
                customer.CustomerAge = ReadLine();
                WriteLine("Enter your Contact number : ");
                customer.CustomerPhoneNumber = Convert.ToDouble(ReadLine());
                WriteLine("Enter your area Pincode : ");
                customer.CustomerPincode = Convert.ToDouble(ReadLine());     
            }
            catch (CustomerException exceptionMessage)
            {
                WriteLine(exceptionMessage.Message);
            }
            catch (System.Exception generalException)
            // Catching the general exceptions.
            {
                WriteLine(generalException.Message);
            }
            return customer;
        }     
    }
}
