﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace StudentWebApp
{
    public partial class AddStudent : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
            try
            {
                ServiceReference1.StudentServiceClient service = new ServiceReference1.StudentServiceClient();

                ServiceReference1.Student stud = new ServiceReference1.Student();
                stud.StudCode = Convert.ToInt32(txtStudCode.Text);
                stud.StudName = txtStudName.Text;
                stud.DeptCode = Convert.ToInt32(txtDeptCode.Text);
                stud.StudDob = Convert.ToDateTime(txtDob.Text);
                stud.Address = txtAddress.Text;

                int recordsAffected = service.AddStudent(stud);
                if (recordsAffected > 0)
                {
                    Response.Write("<script type='text/JavaScript'>alert('Student Record Added Successfully');</script>");
                    Response.Redirect("Home.aspx");
                }
                else
                    Response.Write("<script type='text/JavaScript'>alert('Student Record NOT Added Successfully');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script type='text/JavaScript'>alert('" + ex.Message + "');</script>");
            }
        }
    }
}